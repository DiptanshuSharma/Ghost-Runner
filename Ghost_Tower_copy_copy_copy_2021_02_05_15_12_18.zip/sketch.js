var tower,towerImage;
var door,doorImage;
var doorGroup;
var climber,climberImage;
var climberGroup;
var ghost,ghostImage;
var invisibleBlock,invisibleBlockGroup; 
var gameState;
var spookySound;


function preload(){
  towerImage = loadImage ("tower.png");
  doorImage = loadImage("door.png");
  doorGroup = new Group();
  climberImage = loadImage("climber.png");
  climberGroup = new Group();
  ghostImage =loadImage("ghost-standing.png");
  spookySound = loadSound("spooky.wav");
  
}

function setup(){
  createCanvas(600,600);
  spookySound.loop();
  tower = createSprite(300,300);
  tower.addImage("tower",towerImage);
  tower.velocityY =1;
  
  ghost = createSprite(200,200,50,50);
  ghost.addImage("ghost",ghostImage);
  ghost.scale = 0.3;
  
  invisibleBlockGroup = new Group();
  
  gameState = "play"
  
  
}

function draw(){
  background("black");
   
  if(gameState == "play"){
    

  if(tower.y>400){
    tower.y=300;
    
  }
  if(keyWentDown("left_arrow")){
    ghost.x=ghost.x-3;
  }
  
  if(keyWentDown("right_arrow")){
    ghost.x=ghost.x +3;
  }
   
  if(keyWentDown("space")){
    ghost.velocityY= -5;
  }
  
  if(climberGroup.isTouching(ghost)){
    ghost.velocityY=0;
    gameState = "end";
    
  }
  
  
  spawnDoors();
  drawSprites();
  }

  if(gameState=="end"){
    text("GAME OVER",230,250);
    textSize(30);
    stroke("yellow");
}
  
  
}

function spawnDoors(){
  if(frameCount%240==0){
     door = createSprite(200,-50);
     door.addImage(doorImage);
    
     climber=createSprite(200,10);
     climber.addImage(climberImage);
    
     invisibleBlock = createSprite(200,15);
     invisibleBlock.width = climber.width;
     invisibleBlock.height = 2;
     
     door.x=random(120,400);
     climber.x=door.x;
     invisibleBlock.x = climber.x;
    
     door.velocityY=1;
     climber.velocityY = 1;
     invisibleBlock.velocityY =1;
    
     door.lifetime=800;
     doorGroup.add(door);
     
     climber.lifetime=800;
     climberGroup.add(climber);
    
     invisibleBlockGroup.add(invisibleBlock);
     invisibleBlock.debug = true;
     
     
    ghost.depth = door.depth;
    ghost.depth = ghost.depth+1;
    
    
     
  }
    
}